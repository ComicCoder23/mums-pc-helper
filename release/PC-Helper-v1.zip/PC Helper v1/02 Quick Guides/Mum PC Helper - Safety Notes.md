MUM PC HELPER — SAFETY NOTES


Purpose
These are the core safety rules for using Mum PC Helper.
Read this before making changes.


Main principle
Take the clearest safe win first.
If unsure, leave it alone.


DO NOT TOUCH CASUALLY
- system folders
- unknown files
- Windows components
- security software
- printer software still in use
- saved passwords or browser account data without asking
- unfamiliar startup items that may be system-related


DO NOT DO
- no mass deletion
- no aggressive cleanup tools
- no registry cleaners
- no blind uninstalling
- no disabling startup items you do not understand
- no full browser reset without warning
- no deleting personal files without checking first


SAFE FIRST ACTIONS
- run the audit scripts in the locked order (DiskSpace → Downloads → optional LargeFiles / Programs / Startup)
- review Downloads
- review Desktop clutter
- empty Recycle Bin after cleanup
- record changes in Session Notes


WHEN TO STOP
Stop if:
- you are unsure what the item is
- the likely risk is higher than the likely gain
- the file looks personal or important
- the software looks system-related
- the browser issue may be account-related rather than PC-related


FILES
Before deleting files, ask:
- Do you still need this?
- Do you know what this is?
- Are you worried about losing it?


If the answer is uncertain:
- do not delete it
- write it down for later review


PROGRAMS
Before uninstalling a program, ask:
- Do you still use this?
- Do you know what it does?
- Is it printer, browser, sound, security, or Windows related?


If unsure:
- leave it installed
- note it for later


STARTUP ITEMS
Before disabling a startup item, ask:
- Do you recognize it?
- Is it essential every time the PC starts?
- Could it be needed for security, audio, printing, or syncing?


If unsure:
- leave it enabled


BROWSER ISSUES
If the complaint is browser-related:
- treat it as a browser problem first
- check tabs, extensions, homepage, and search engine
- do not over-clean the whole PC unless there is wider evidence


REPORTS
The reports are for visibility.
They are not permission to delete things blindly.


SUCCESS RULE
A good session does not mean fixing everything.
A good session means:
- taking the safest useful action
- avoiding damage
- improving clarity
- leaving good notes for next time


FINAL RULE
Audit first.
Review second.
Act carefully.
If unsure, stop.
